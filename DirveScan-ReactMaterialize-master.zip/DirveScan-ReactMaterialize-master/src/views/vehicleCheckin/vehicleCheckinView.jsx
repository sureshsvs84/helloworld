import React from 'react';
import ReactDom from 'react-dom';
import {Card, Col,Input,Row,Button} from 'react-materialize'
import VehicleCheckin from '../../components/appComponent/vehicleCheckin';
class VehicleCheckinView extends React.Component {
    render() {
       return (
          
             <VehicleCheckin/>
        
           
       )
    }
 }

export default VehicleCheckinView;