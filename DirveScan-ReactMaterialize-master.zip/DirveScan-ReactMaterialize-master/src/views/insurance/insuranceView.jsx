import React from 'react';
import ReactDom from 'react-dom';
import {Card, Col,Input,Row,Button} from 'react-materialize'
import Insurance from '../../components/appComponent/insurance/insurance';
class InsuranceView extends React.Component {
    render() {
       return (
              <Insurance/> 
               )
    }
 }

export default InsuranceView;