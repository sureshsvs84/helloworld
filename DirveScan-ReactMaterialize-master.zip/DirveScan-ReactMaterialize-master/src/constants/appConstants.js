export const appConstants = {
    ELEMENT_TO_BOOTSTRAP  : 'app',
    ORDER_GRID_PAGE_SIZE :10
};

export const appConfiguration = {
};

export const appSettings = {
};

export const httpMethodType = {
    GET: 'GET',
    POST: 'POST',
    PUT: 'PUT',
    DELETE: 'DELETE'
};
   