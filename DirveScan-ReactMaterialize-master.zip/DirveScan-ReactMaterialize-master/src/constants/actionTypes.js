
export const offeringsActionTypes ={
     read_offering_detail : 'Read_Offering_Detail',
     read_offering_detail_success : 'READ_OFFERING_DETAIL_SUCCESS',
     read_offering_detail_error : 'READ_OFFERING_DETAIL_ERROR'
}


