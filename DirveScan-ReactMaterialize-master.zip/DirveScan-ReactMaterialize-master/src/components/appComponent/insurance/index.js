import Insurance from "./insurance";
export default Insurance;