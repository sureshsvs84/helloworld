setup:
Install required packages:
	command => npm install
creating build application:
	command => npm run serve