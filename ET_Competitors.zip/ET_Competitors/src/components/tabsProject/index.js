import TabsProject from './tabsProject'


export default TabsProject;