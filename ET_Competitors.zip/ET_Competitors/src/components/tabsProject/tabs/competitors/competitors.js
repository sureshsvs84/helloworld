import React, {Component, Fragment} from 'react';
import {Col} from 'react-materialize';
import {TatvamButton} from "../../../../functionalComponents";
import CompetitorsGrid from "../../../../applicationComponent/competitors/list";
import Modal from '../../../../applicationComponent/competitors/modal';

class Competitors extends Component {
    constructor(props) {
        super(props);
         this.state = {
            competitorModal: false,
            children:"",
            colDef: [{headerName: 'Competitor ID', field: 'id'},
                     {headerName: 'Competitor Name', field: 'name'}],
            selectedCompetitordata:""
        }
    }
   
    _addCompetitor = (e) => {       
        this.setState({
            competitorModal: true,
            title:"Add Competitor"
            
        })
    };
    __onEditRowClick = (data) => {
        this.setState({
            competitorModal: true,
            title:"Edit competitor",          
            selectedCompetitordata: data
        })
    };
    __onDeleteRowClick = (data) => {
        alert("Delete");
    };
    closeModal = (name) => {
        this.setState({
            competitorModal: false,
            selectedCompetitordata:""

        })
    };
    componentDidMount(){
        this.props.actions.fetchCompetitors();        
    }
    render() {
        return (
            <Fragment>
               <TatvamButton className="mt-2 ml-2 mr-2 mb-2  right btn_primary" name="addCompetitor" onClick={this._addCompetitor}>Add
                 Competitor</TatvamButton>               
                 
           { this.state.competitorModal &&  
           <Modal isModalopen={this.state.competitorModal}
                  isModalheader={this.state.title} competitorsList={this.props.gridData} 
                  competitorModal={this.state.competitorModal} 
                  closeModal={this.closeModal}
                  selectedCompetitordata={this.state.selectedCompetitordata}>
           </Modal>
            }

            <Col s={12}>
                 <CompetitorsGrid gridData={this.props.gridData} colData={this.state.colDef} onRowEdit={this.__onEditRowClick} onRowDelete={this.__onDeleteRowClick}/>
            </Col>
            </Fragment>
        )
    }
}

export default Competitors;