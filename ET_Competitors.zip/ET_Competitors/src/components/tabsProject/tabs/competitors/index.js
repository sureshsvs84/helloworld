import Competitors from './competitors'
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {fetchCompetitors} from "../../../../actions";

const mapStateToProps = (state) => {
    return {
        gridData:state.competitor.competitorsList
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(
            {
                fetchCompetitors
            },
            dispatch
        )
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Competitors);


