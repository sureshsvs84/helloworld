import Properties from './properties'
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {fetchProperties} from "../../../../actions";

const mapStateToProps = (state) => {
    return {
        gridData:state.property.propertyList
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(
            {
                fetchProperties
            },
            dispatch
        )
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Properties);


