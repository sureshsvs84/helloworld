import React, {Component, Fragment} from 'react';
import {Col} from 'react-materialize';
import {TatvamButton} from "../../../../functionalComponents";
import PropertyGrid from "../../../../applicationComponent/properties/list";
import Modal from '../../../../applicationComponent/properties/modal';

class Properties extends Component {
    constructor(props) {
        super(props);
         this.state = {
            propertyModal: false,
            children:"",
            colDef: [{headerName: 'property ID', field: 'id'},
                     {headerName: 'property Name', field: 'name'}],
            selectedPropertydata:""
        }
    }
   
    _addProperty = (e) => {       
        this.setState({
            propertyModal: true,
            title:"Add Property"
            
        })
    };
    __onEditRowClick = (data) => {
        this.setState({
            propertyModal: true,
            title:"Edit Property",          
            selectedPropertydata: data
        })
    };
    __onDeleteRowClick = (data) => {
        alert("Delete");
    };
    closeModal = (name) => {
        this.setState({
            propertyModal: false,
            selectedPropertydata:""

        })
    };
    componentDidMount(){
        this.props.actions.fetchProperties();        
    }
    render() {
        return (
            <Fragment>
               <TatvamButton className="mt-2 ml-2 mr-2 mb-2  right btn_primary"  onClick={this._addProperty}>Add
                 Property</TatvamButton>               
                 
           { this.state.propertyModal &&  
           <Modal isModalopen={this.state.propertyModal}
                  isModalheader={this.state.title} propertyList={this.props.gridData} 
                  propertyModal={this.state.propertyModal} 
                  closeModal={this.closeModal}
                  selectedPropertydata={this.state.selectedPropertydata}>
           </Modal>
            }

            <Col s={12}>
                 <PropertyGrid gridData={this.props.gridData} colData={this.state.colDef} onRowEdit={this.__onEditRowClick} onRowDelete={this.__onDeleteRowClick}/>
            </Col>
            </Fragment>
        )
    }
}

export default Properties;