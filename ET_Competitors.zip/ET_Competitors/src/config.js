export const API_URL = process.env.NODE_ENV === 'dev ' ? 'https://rapter-api.admin.mpr.works' : 'https://rapter-api.admin.mpr.works';
export const BACKEND_URL = process.env.NODE_ENV === 'production' ? 'http://192.168.50.129:3000' : 'http://localhost:3000';

