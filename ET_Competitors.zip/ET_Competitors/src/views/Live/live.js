import React, {Component} from 'react';
import {Input} from 'react-materialize';

class Live extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div>
                Live Page
            </div>
        )
    }
}

export default Live;