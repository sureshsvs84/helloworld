import React, {Component} from 'react';
import {Input} from 'react-materialize';


class Masters extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div>
                Masters Page
            </div>
        )
    }
}

export default Masters;