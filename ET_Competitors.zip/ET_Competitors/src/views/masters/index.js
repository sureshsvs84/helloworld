import Masters from './masters'

export default Masters;