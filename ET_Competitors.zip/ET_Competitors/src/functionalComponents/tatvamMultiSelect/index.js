import TatvamMultiSelect from './tatvamMultiSelect';

export default TatvamMultiSelect;