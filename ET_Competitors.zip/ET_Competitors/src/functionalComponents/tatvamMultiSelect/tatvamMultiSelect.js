import {BaseMultiSelect} from "../../baseComponents";

class TatvamMultiSelect extends BaseMultiSelect {

}

export default TatvamMultiSelect;