// import BaseSwitch  from "../../baseComponents/baseSwitch";

// class TatvamSwitch extends BaseSwitch {

// }

// export default TatvamSwitch;