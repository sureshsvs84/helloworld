import {BaseTab, BaseTabList, BaseTabPanel, BaseTabs} from '../../baseComponents';

class TatvamTabs extends BaseTabs {

}


class TatvamTab extends BaseTab {

}


class TatvamTabList extends BaseTabList {

}


class TatvamTabPanel extends BaseTabPanel {

}

export default {TatvamTabPanel, TatvamTabList, TatvamTab, TatvamTabs};