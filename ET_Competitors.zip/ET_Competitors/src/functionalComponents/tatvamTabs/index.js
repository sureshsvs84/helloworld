import {TatvamTab, TatvamTabList, TatvamTabPanel, TatvamTabs} from './tatvamTabs';

export default {TatvamTabPanel, TatvamTabList, TatvamTab, TatvamTabs};