import {BaseCol} from "../../baseComponents";

class TatvamCol extends BaseCol {

}

export default TatvamCol;