import TatvamCol from './tatvamCol';

export default TatvamCol;