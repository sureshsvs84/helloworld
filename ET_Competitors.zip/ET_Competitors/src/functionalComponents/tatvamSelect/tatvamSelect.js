import {BaseSelect} from "../../baseComponents";

class TatvamSelect extends BaseSelect {

}

export default TatvamSelect;