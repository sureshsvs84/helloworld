import TatvamSelect from './tatvamSelect';

export default TatvamSelect;