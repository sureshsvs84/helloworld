import React, {Component} from 'react';

class ColumnContextMenu extends Component {

    render() {
        return (
            <a><i className="material-icons" title='Delete'>delete</i></a>
        );
    }
}

export default ColumnContextMenu;