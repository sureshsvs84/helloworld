import {BaseModal} from "../../baseComponents";

class TatvamModal extends BaseModal {

}

export default TatvamModal;