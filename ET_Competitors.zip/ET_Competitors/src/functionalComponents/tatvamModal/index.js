import TatvamModal from './tatvamModal';

export default TatvamModal;