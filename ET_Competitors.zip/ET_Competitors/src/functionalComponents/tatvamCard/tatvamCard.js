import {BaseCard} from "../../baseComponents";

class TatvamCard extends BaseCard {

}

export default TatvamCard;