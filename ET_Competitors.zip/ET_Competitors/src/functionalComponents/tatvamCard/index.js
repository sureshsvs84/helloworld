import TatvamCard from './tatvamCard';

export default TatvamCard;