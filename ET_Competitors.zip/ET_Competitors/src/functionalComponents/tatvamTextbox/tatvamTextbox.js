import {BaseTextInput} from "../../baseComponents";

class TatvamTextBox extends BaseTextInput {

}

export default TatvamTextBox;