// import {BaseRow} from "../../baseComponents";

// class TatvamRow extends BaseRow {
//     constructor(props){
//         super(props)
//     }

// }

// export default TatvamRow;