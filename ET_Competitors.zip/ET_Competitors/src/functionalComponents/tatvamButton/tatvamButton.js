import {BaseButton} from "../../baseComponents";

class TatvamButton extends BaseButton {

}

export default TatvamButton;