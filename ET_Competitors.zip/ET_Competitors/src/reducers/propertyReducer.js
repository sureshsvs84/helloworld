import Data from '../../data/competitors';

const initialState = {
    propertyList:Data,
    error: {}
};

const store = (state = initialState, action) => {
    switch (action.type) {
        case 'GET_PROPERTY_SUCCESS':
            state = {
                ...state,
            };
            return state;
        
        default:
            return state;

    }

};

export default store;


