import Data from '../../data/competitors';

const initialState = {
    competitorsList:Data,
    error: {}
};

const store = (state = initialState, action) => {
    switch (action.type) {
        case 'GET_COMPETITOR_SUCCESS':
            state = {
                ...state,
                //competitorslist: action.payload
            };
            return state;
        
        default:
            return state;

    }

};

export default store;


