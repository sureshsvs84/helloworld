import CompetitorsGrid from './competitors';

export default CompetitorsGrid
// import { bindActionCreators } from 'redux';
// import { connect } from 'react-redux';
// import { fetchCustomerUser } from '../../../actions';


// const mapStateToProps = (state) => {
//     return {}
// };

// const mapDispatchToProps = (dispatch) => {
//     debugger;
//     return {
//         actions: bindActionCreators(
//             {
//                 fetchCustomerUser
//             },
//             dispatch
//         )
//     };
// };

// export default connect(mapStateToProps, mapDispatchToProps)(CompetitorsGrid);


