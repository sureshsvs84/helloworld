import React, {Component} from 'react';
import {TatvamModal} from '../../../functionalComponents';
import Create from '../create';


class CompetitorModal extends Component {
  
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <TatvamModal
                open={this.props.isModalopen}
                header={this.props.isModalheader}
                options={{dismissible: false}}                
                fixedFooter={false}
                children={<Create closeModal={this.props.closeModal} competitorsList={this.props.competitorsList} competitorModal={this.props.competitorModal} selectedCompetitordata={this.props.selectedCompetitordata}/>}
                 >
            </TatvamModal> 
        );
    }
}

export default CompetitorModal;