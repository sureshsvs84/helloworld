import CompetitorModal from './modal';
import {fetchCompetitors} from '../../../actions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';


const mapStateToProps = (state, ownProps) => {
    return {
    }
};
const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(
            {
            fetchCompetitors
            },
            dispatch
        )
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(CompetitorModal);

