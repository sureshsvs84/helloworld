import React, {Component,Fragment} from 'react';
import {Row} from 'react-materialize';
import {TatvamGrid} from "../../../functionalComponents";


class PropertyGrid extends Component {
   
render() {
    return (
        <Fragment>
            <Row>
                <TatvamGrid gridData={this.props.gridData} colData={this.props.colData} onRowEdit={this.props.onRowEdit} onRowDelete={this.props.onRowDelete} />
            </Row>
        </Fragment>
    )
}
}
export default PropertyGrid;

