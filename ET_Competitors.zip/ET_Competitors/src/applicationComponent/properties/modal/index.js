import PropertyModal from './modal';
import {fetchProperties} from '../../../actions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';


const mapStateToProps = (state, ownProps) => {
    return {
    }
};
const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(
            {
                fetchProperties
            },
            dispatch
        )
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(PropertyModal);

