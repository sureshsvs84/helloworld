import React, {Component} from 'react';
import {TatvamModal} from '../../../functionalComponents';
import Create from '../create';


class PropertyModal extends Component {
  
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <TatvamModal
                open={this.props.isModalopen}
                header={this.props.isModalheader}
                options={{dismissible: false}}                
                fixedFooter={false}
                children={<Create closeModal={this.props.closeModal} propertyList={this.props.propertyList} propertyModal={this.props.propertyModal} selectedPropertydata={this.props.selectedPropertydata}/>}
                 >
            </TatvamModal> 
        );
    }
}

export default PropertyModal;