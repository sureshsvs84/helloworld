import React, { Component, Fragment } from 'react';
import { Row } from 'react-materialize';
import { TatvamCol, TatvamMultiSelect,TatvamButton } from '../../../functionalComponents';
import { _ } from 'ag-grid-community';

class Create extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            propertyListOptions: [],
            selectedValues: []
        };
    }
    
    _propertyClicked = (selectedOption) => {
        this.setState({selectedValues: selectedOption });
      }
     componentDidMount() {
         let optionLists = [];
         let selectedPropertyvalues = [];
            this.props.propertyList.length > 0 && this.props.propertyList.map((data, index) => {
                            optionLists.push({ label: data.name, value: data.id });
                        });
         if(this.props.selectedPropertydata!=""){
            selectedPropertyvalues.push({ label: this.props.selectedPropertydata.name, value: this.props.selectedPropertydata.id });
             }
            this.setState({
                propertyListOptions: optionLists,
                selectedValues:selectedPropertyvalues
            });       
    }
 
    render() {
        return (
            <Fragment>
                <Row >
                    <div className="col s12 valign-wrapper">
                        <label htmlFor="property" className="col s4 property-label">
                            Properties:
                        </label>
                        <TatvamCol m={8} className="mt-.75">
                            <TatvamMultiSelect
                                classNamePrefix="react-select"
                                value={this.state.selectedValues}
                                //default={this.state.selectedvalues}
                                isMulti
                                name="operation"
                                onChange={this._propertyClicked}
                                options={this.state.propertyListOptions}
                                //isDisabled={this.state.applicationMode == 'VIEW'}
                                placeholder="Select properties"
                            />
                        </TatvamCol>
                    </div>
                </Row>
           
                <Row className="pb-2 pr-2">
                            <TatvamButton
                                    waves="light"
                                    className="mt-1 mr-1 CreateProjectPublish btn_primary waves"
                                    onClick={this.props.closeModal}
                                >
                                    Discard
                            </TatvamButton>
                            <TatvamButton
                                    waves="light"
                                    className="mt-1 CreateProjectPublish btn_primary "
                                    onClick={this._triggerSubmit}
                                    disabled={this.state.name === ''}
                                >
                                    Save
                            </TatvamButton>
                </Row>
            </Fragment>

        );
    }
}

export default Create;