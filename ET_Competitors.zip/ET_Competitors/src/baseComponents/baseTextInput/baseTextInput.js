import {TextInput} from 'react-materialize';

class BaseTextInput extends TextInput {

}

export default BaseTextInput;