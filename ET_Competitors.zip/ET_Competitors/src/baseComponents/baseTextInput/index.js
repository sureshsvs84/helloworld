import BaseTextInput from "./baseTextInput";

export default BaseTextInput;