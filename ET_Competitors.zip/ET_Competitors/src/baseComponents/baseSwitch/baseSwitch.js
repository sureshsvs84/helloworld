import {Switch} from 'react-materialize';

class BaseSwitch extends Switch {

}

export default BaseSwitch;