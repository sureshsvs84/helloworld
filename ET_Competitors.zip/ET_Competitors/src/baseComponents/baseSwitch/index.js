import {BaseSwitch} from "./baseSwitch";

export default BaseSwitch;