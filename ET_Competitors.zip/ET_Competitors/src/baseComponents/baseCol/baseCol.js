import {Col} from 'react-materialize';

class BaseCol extends Col {

}

export default BaseCol;