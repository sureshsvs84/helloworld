import BaseCol from './baseCol';

export default BaseCol;