import {Modal} from 'react-materialize';

class BaseModal extends Modal {

}

export default BaseModal;