import BaseModal from "./baseModal";

export default BaseModal;