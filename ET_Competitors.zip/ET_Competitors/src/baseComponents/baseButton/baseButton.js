import {Button} from 'react-materialize';

class BaseButton extends Button {

}

export default BaseButton;