import {BaseTab, BaseTabList, BaseTabPanel, BaseTabs} from "./baseTabs";

export {BaseTabPanel, BaseTabList, BaseTab, BaseTabs};