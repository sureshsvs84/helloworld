import {AgGridReact} from "ag-grid-react";

class BaseGrid extends AgGridReact {
    constructor(props) {
        super(props);
    }
}

export default BaseGrid;