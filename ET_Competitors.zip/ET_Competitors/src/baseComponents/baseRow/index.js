import BaseRow from './baseRow';

export default BaseRow;