import {Row} from 'react-materialize';

class BaseRow extends Row {

}

export default BaseRow;