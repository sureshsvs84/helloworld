import {Card} from 'react-materialize';


class BaseCard extends Card {

}

export default BaseCard;