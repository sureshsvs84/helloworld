import BaseCard from "./baseCard";

export default BaseCard;