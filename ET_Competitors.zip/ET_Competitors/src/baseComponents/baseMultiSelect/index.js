import BaseMultiSelect from "./baseMultiSelect";

export default BaseMultiSelect;