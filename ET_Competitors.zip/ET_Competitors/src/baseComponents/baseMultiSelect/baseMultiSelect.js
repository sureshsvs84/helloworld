import Select from 'react-select';


class BaseMultiSelect extends Select {

}

export default BaseMultiSelect;