import BaseSelect from "./baseSelect";

export default BaseSelect;