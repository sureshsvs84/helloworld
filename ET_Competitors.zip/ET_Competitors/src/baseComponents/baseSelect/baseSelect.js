import {Select} from 'react-materialize';

class BaseSelect extends Select {

}

export default BaseSelect;