
const actions = {
    GetCompetitorSuccess: (payload) => {
        return {
            type: 'GET_COMPETITOR_SUCCESS',
            payload: payload,
        };
    },
    GetCompetitorError: (payload) => {
        return {
            type: 'GET_COMPETITOR_Error',
            payload: payload,
        };
    }
};
export const fetchCompetitors= () => (dispatch, getState) => {
    dispatch(actions.GetCompetitorSuccess());


}