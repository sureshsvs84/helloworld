
const actions = {
    GetPropertySuccess: (payload) => {
        return {
            type: 'GET_PROPERTY_SUCCESS',
            payload: payload,
        };
    },
    GetPropertyError: (payload) => {
        return {
            type: 'GET_PROPERTY_Error',
            payload: payload,
        };
    }
};
export const fetchProperties= () => (dispatch, getState) => {
    dispatch(actions.GetPropertySuccess());


}