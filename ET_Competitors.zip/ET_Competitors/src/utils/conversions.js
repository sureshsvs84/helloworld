class Conversions {
    toObject(arr, key) {
        // array length
        // key exist
        arr.map((data, index) => {
        })
    }
}